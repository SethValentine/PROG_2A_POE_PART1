﻿using StartOver.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace StartOver
{
    /// <summary>
    /// Interaction logic for Stepsdescription.xaml
    /// </summary>
    public partial class Stepsdescription : Window
    {
        private Lists recipe;
        private List<Lists> recipes;
        private int stepsCounter;
        private int steps;
        private int currentStep = 1;

        public Stepsdescription(int steps, Lists recipe, List<Lists> recipes)
        {
            InitializeComponent();
            this.steps = steps;
            this.recipe = recipe;
            this.recipes = recipes;
            stepsCounter = 1;
            
        }

        private void Confirmo_Click(object sender, RoutedEventArgs e)
        {
            string stepDescription = SDescription.Text;

            // Validate step description
            if (string.IsNullOrEmpty(stepDescription)) // valdations for the steps descritptions
            {
                MessageBox.Show("Please enter a step description.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Add the step description to the recipe
            recipe.newSteps.Add(stepDescription);

            MessageBox.Show($"Step description has been saved for step #{stepsCounter}");

            // Clear the TextBox for the next step
            SDescription.ClearInput7();

            // Increment the step counter
            stepsCounter++;
            currentStep++;

            if (stepsCounter > steps)
            {
                // All steps have been entered
                // Add the updated recipe to the list
                recipes.Add(recipe);

                // Close the current window
                MainWindow main = new MainWindow();
                main.Show();
                this.Close();
            }
            
        }

    }
}
