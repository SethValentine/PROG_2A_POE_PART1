﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StartOver.Core
{
    public class Lists
    {
        public string newName { get; set; }
        public List<string> newIngredients { get; set; }
        public List<double> newQuantities { get; set; }
        public List<string> newMeasurements { get; set; }
        public List<string> newSteps { get; set; }
        public List<double> newCalories { get; set; }
        public List<string> newFoodGroup { get; set; }

        public Lists(string recipeName)
        {
            newName = recipeName;
            newIngredients = new List<string>();
            newQuantities = new List<double>();
            newMeasurements = new List<string>();
            newSteps = new List<string>();
            newCalories = new List<double>();
            newFoodGroup = new List<string>();
        }
    }
}
