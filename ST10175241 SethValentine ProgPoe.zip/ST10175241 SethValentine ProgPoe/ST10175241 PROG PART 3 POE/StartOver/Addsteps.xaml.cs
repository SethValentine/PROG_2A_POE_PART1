﻿using StartOver.Core;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace StartOver
{
    /// <summary>
    /// Interaction logic for Addsteps.xaml
    /// </summary>
    public partial class Addsteps : Window
    {
        private Lists recipe;
        private List<Lists> recipes;
        public Addsteps(Lists recipe, List<Lists> recipes)
        {
            InitializeComponent();
            this.recipe = recipe;
            this.recipes = recipes;
        }



        private void addSteps(List<Lists> recipes) // calling the ArrayLists in Lists class
        {

            int steps;
            if (!int.TryParse(Numofsteps.Text.Trim(), out steps))
            {
                MessageBox.Show("Incorrect input", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else if (steps <= 0)
            {
                MessageBox.Show("Please enter a positive number", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            recipe.newSteps.Add(Numofsteps.Text);
            recipes.Add(recipe);

            // Close the current window and return to the main window
            Stepsdescription desc = new Stepsdescription(steps,recipe,recipes);
            desc.Show();
            this.Close();
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            addSteps(recipes);
        }
    }
}
