﻿using StartOver.Core;
using StartOver.Model;
using StartOver.View.UserControls;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace StartOver
{
    /// <summary>
    /// Interaction logic for Child.xaml
    /// </summary>
    public partial class Child : Window
    {
        public RecipeCollection RecipeCollection { get; }

        private Lists recipe;
        private List<Lists> recipes; // callling the list class that i made that stores the arraylists
        private int size;
        private int currentingredientnumber;

        private Txtplaceholder txtPlaceholder;
        private QuantityHolder quantityholder;
        private Measurementholder measurementholder;
        private Calorieholder calorieholder;
        private Comboboxholder comboboxholder;

        public Child(int size, Lists recipe, List<Lists> recipes, string recipeName )
        {
            InitializeComponent();
         
            this.size = size;
            this.recipes = new List<Lists>();

            txtPlaceholder = new Txtplaceholder();
            quantityholder = new QuantityHolder();
            measurementholder = new Measurementholder();
            calorieholder = new Calorieholder();
            comboboxholder = new Comboboxholder();

            currentingredientnumber = 1;
        }
        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            RecipeItem recipeItem = (RecipeItem)DataContext;

            Ingredient.ClearInput();
            Foodgroup.ClearInput5();
            Quantity.ClearInput2();
            Measurement.ClearInput3();
            Calories.ClearInput4();

            recipeItem.Ingredient = string.Empty;
            recipeItem.FoodGroup = string.Empty;
            recipeItem.Quantity = string.Empty;
            recipeItem.Measurement = string.Empty;
            recipeItem.Calories = string.Empty;
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
           
            

            
            // Validate inputs before saving
            if (!ValidateInput())
                return;

            string recipeName = ChildName.Text;
            recipeDetails(recipes, recipeName);

            MessageBox.Show($"Recipe details have been saved for ingredient #{currentingredientnumber}");

            Ingredient.ClearInput();
            Foodgroup.ClearInput5();
            Quantity.ClearInput2();
            Measurement.ClearInput3();
            Calories.ClearInput4();

            if (size > 1)
            {
                // Decrement the remaining ingredient count
                size--;
                currentingredientnumber++;
            }
            else
            {
                // Close the child form window when all ingredients have been processed
                Addsteps addStepsWindow = new Addsteps(recipe,recipes);
                addStepsWindow.Show();
                this.Close();
            }
        }

        private bool ValidateInput()
        {
            string ingredient = Ingredient.Text.Trim(); // valadting all the ingreidents for the recipe
            if (string.IsNullOrEmpty(ingredient) || !ingredient.Split().All(input => input.All(char.IsLetter)))
            {
                MessageBox.Show("Wrong input. Please enter a valid ingredient name.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (Foodgroup.SelectedItem == null) // valdations for the foodgroup
            {
                MessageBox.Show("Please select a food group.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!double.TryParse(Quantity.Text.Trim(), out double quantity)) // valdations for the quantity
            {
                MessageBox.Show("Invalid input for Quantity. Please enter a valid numerical value.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            string measurement = Measurement.Text.Trim(); // valdations for the unit of measurement
            if (string.IsNullOrEmpty(measurement))
            {
                MessageBox.Show("Please enter a measurement.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!double.TryParse(Calories.Text.Trim(), out double calories)) // valdations for the Calories
            {
                MessageBox.Show("Invalid input for Calories. Please enter a valid numerical value.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            return true;
        }

        private void recipeDetails(List<Lists> recipes, string recipeName)
        {


            //This asks the user to enter the details for the recipe such as the ingredient, quantity and the measurement
            for (int i = 0; i < size; i++)
            {
                this.recipe = new Lists(recipeName);
                string ingredient;
                do
                {
                    //Takes user input for the ingredient
                    ingredient = Ingredient.Text;

                    //If the user input contains integers then it will display and error
                    //This code is modified to allow the user to include spaces in their ingredient name using Split()
                    if (!ingredient.Split().All(input => input.All(char.IsLetter)))
                    {
                        MessageBox.Show("Wrong input. Please try again", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    else
                    {
                        break;
                    }
                } while (true);

                string foodGroupcode = null;
                if (Foodgroup.SelectedItem != null)
                {
                    foodGroupcode = Foodgroup.SelectedItem.ToString();
                }
                else
                {
                    // Handle the case when no item is selected
                    MessageBox.Show("Please select a food group.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                //Implementing error handling so that if the user types the wrong input it will display an error and allow them to retypetheir input until the applciation accepts their input

                double quantity = 0.0;
                double parsedQuantity = 0.0;
                if (!string.IsNullOrWhiteSpace(Quantity.Text) && !double.TryParse(Quantity.Text.Trim(), out parsedQuantity))
                {
                    MessageBox.Show("Invalid input for Quantity. Please enter a valid numerical value.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                else
                {
                    quantity = parsedQuantity;
                }

                string measurement = Measurement.Text;

                double calories = 0.0;
                double parsedCalories = 0.0;
                if (!string.IsNullOrWhiteSpace(Calories.Text) && !double.TryParse(Calories.Text.Trim(), out parsedCalories))
                {
                    MessageBox.Show("Invalid input for Calories. Please enter a valid numerical value.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                else
                {
                    calories = parsedCalories;
                }


                //This adds the input from the user to the lists

                recipe.newIngredients.Add(ingredient);
                recipe.newQuantities.Add(quantity);
                recipe.newMeasurements.Add(measurement);
                recipe.newFoodGroup.Add(foodGroupcode);
                recipe.newCalories.Add(calories);



            }

            //Again the user input is added to the lists

            recipes.Add(recipe);

        }
    }
}
