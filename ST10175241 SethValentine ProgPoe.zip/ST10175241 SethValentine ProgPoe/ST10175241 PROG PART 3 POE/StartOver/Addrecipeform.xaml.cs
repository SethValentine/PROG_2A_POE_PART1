﻿using StartOver.Core;
using StartOver.View.UserControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace StartOver
{
    /// <summary>
    /// Interaction logic for Addrecipeform.xaml
    /// </summary>
    public partial class Addrecipeform : Window, INotifyPropertyChanged
    {
        private List<Lists> recipes;  // calling the lists where i saved everything in a list
        private bool isNameValidated; // validating the name of the recipe
        private bool isNumOfIngredientsValidated; // validating the number of recipes

        public Addrecipeform()
        {
            InitializeComponent();
            DataContext = this;
            
            recipes = new List<Lists>();
            isNameValidated = false;
            isNumOfIngredientsValidated = false;
        }

        private string nameTransfer;

        public event PropertyChangedEventHandler? PropertyChanged;

        public string NameTransfer
        {
            get { return nameTransfer; }
            set
            {
                nameTransfer = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("NameTransfer")); // adds the name of the recipe on top of the window
            }
        }

        private void NextForm_Click(object sender, RoutedEventArgs e)
        {
            // Validate inputs before proceeding
            ValidateName(RenameChild.Text);
            ValidateNumOfIngredients();

            // Check if both inputs are validated
            if (!isNameValidated || !isNumOfIngredientsValidated)
            {
                return;
            }

            addIngredients(recipes);
            
        }

        private void addIngredients(List<Lists> recipes)
        {
            string recipeName = RenameChild.Text;

            // Check if the recipe name is empty or contains only whitespace
            if (string.IsNullOrWhiteSpace(recipeName))
            {
                MessageBox.Show("Please enter a recipe name", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            Lists existingRecipe = recipes.FirstOrDefault(r => r.newName.Equals(recipeName, StringComparison.OrdinalIgnoreCase));
            if (existingRecipe != null)
            {
                MessageBox.Show("Recipe already exists");
                return;
            }

            Lists recipe = new Lists(recipeName);
            
            int size;
            if (!int.TryParse(Numofingredients.Text.Trim(), out size)) // Valadations to input a number to add the ingreidents
            {
                MessageBox.Show("Incorrect input", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            else if (size <= 0)
            {
                MessageBox.Show("Please enter a positive number", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            recipes.Add(recipe);

            Child childWindow = new Child(size, recipe, recipes, recipeName);
            childWindow.DataContext = this; // Set the data context of the child window to the current instance of MainWindow
            childWindow.Show();
            this.Close();

        }

        private void ValidateName(string recipeName) // validate to enter a valid recipe name
        {
            if (int.TryParse(recipeName, out _))
            {
                MessageBox.Show("Please enter a valid recipe name", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                isNameValidated = false;
            }
            else if (string.IsNullOrWhiteSpace(recipeName))
            {
                MessageBox.Show("Please enter a recipe name", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                isNameValidated = false;
            }
            else
            {
                isNameValidated = true;
            }
        }

        private void ValidateNumOfIngredients() // validate the ingreidents 
        {
            int size;
            if (Numofingredients.Text == null || !int.TryParse(Numofingredients.Text.Trim(), out size))
            {
                MessageBox.Show("Incorrect input", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                isNumOfIngredientsValidated = false;
            }
            else if (size <= 0)
            {
                MessageBox.Show("Please enter a positive number", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                isNumOfIngredientsValidated = false;
            }
            else
            {
                isNumOfIngredientsValidated = true;
            }
        }
    }
}
