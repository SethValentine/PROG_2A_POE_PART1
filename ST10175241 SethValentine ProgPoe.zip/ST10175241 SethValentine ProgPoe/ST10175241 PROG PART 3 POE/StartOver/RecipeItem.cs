﻿using System.ComponentModel;

namespace StartOver.Model
{
    public class RecipeItem : INotifyPropertyChanged
    {
        private string ingredient;
        public string Ingredient
        {
            get { return ingredient; }
            set
            {
                ingredient = value;
                OnPropertyChanged(nameof(Ingredient));
            }
        }

        private string foodGroup;
        public string FoodGroup
        {
            get { return foodGroup; }
            set
            {
                foodGroup = value;
                OnPropertyChanged(nameof(FoodGroup));
            }
        }

        private string quantity;
        public string Quantity
        {
            get { return quantity; }
            set
            {
                quantity = value;
                OnPropertyChanged(nameof(Quantity));
            }
        }

        private string measurement;
        public string Measurement
        {
            get { return measurement; }
            set
            {
                measurement = value;
                OnPropertyChanged(nameof(Measurement));
            }
        }

        private string calories;
        public string Calories
        {
            get { return calories; }
            set
            {
                calories = value;
                OnPropertyChanged(nameof(Calories));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}

