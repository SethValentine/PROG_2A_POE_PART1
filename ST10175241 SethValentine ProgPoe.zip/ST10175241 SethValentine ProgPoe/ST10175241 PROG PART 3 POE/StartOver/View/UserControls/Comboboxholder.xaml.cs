﻿using System.Windows.Controls;
using System.Windows;
using System.Security.Cryptography;

namespace StartOver.View.UserControls
{
    public partial class Comboboxholder : UserControl
    {
        public Comboboxholder()
        {
            InitializeComponent();
            
        }

        private string placeholder;
        public string Placeholder
        {
            get { return placeholder; }
            set
            {
                placeholder = value;
                tbPlaceHolder.Text = placeholder;
            }
        }

        private void Foodgroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedFoodgroup = Foodgroup.SelectedItem as ComboBoxItem;

            if (selectedFoodgroup != null)
            {
                // Hide the default message
                tbPlaceHolder.Visibility = Visibility.Hidden;

                // Display the selected content
                tbPlaceHolder.Text = selectedFoodgroup.Content.ToString();
            }
        }

        public object SelectedItem
        {
            get { return Foodgroup.SelectedItem; }
            set { Foodgroup.SelectedItem = value; }
        }

        public void ClearInput5()
        {
            // Deselect any selected item
            Foodgroup.SelectedIndex = -1;
            // Show the default message
            tbPlaceHolder.Visibility = Visibility.Visible;
            // Set the default message text
            tbPlaceHolder.Text = "Select a foodgroup"; 
        }
    }
}
