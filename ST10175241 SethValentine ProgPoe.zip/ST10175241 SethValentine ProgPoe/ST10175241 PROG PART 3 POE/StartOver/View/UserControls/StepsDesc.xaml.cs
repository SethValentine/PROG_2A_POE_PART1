﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StartOver.View.UserControls
{
    /// <summary>
    /// Interaction logic for StepsDesc.xaml
    /// </summary>
    public partial class StepsDesc : UserControl
    {
        public StepsDesc()
        {
            InitializeComponent();
        }
        public string Text
        {
            get { return SDescription.Text; }
            set { SDescription.Text = value; }
        }

        private string placeholder;
        public string Placeholder
        {
            get { return placeholder; }
            set
            {
                placeholder = value;
                tbPlaceHolder.Text = placeholder;

            }
        }

        private void SDescription_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(SDescription.Text))
                tbPlaceHolder.Visibility = Visibility.Visible;
            else
                tbPlaceHolder.Visibility = Visibility.Hidden;
        }

        public void ClearInput7()
        {
            SDescription.Clear();

        }
    }
}
