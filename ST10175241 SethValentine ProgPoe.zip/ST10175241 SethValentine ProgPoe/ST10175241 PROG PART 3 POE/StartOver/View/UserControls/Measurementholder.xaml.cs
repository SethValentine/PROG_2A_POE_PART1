﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StartOver.View.UserControls
{
    /// <summary>
    /// Interaction logic for Measurementholder.xaml
    /// </summary>
    public partial class Measurementholder : UserControl
    {
        public Measurementholder()
        {
            InitializeComponent();
        }

        private string placeholder;
        public string Placeholder
        {
            get { return placeholder; }
            set
            {
                placeholder = value;
                tbPlaceHolder.Text = placeholder;

            }
        }
        public string Text
        {
            get { return Measurement.Text; }
            set { Measurement.Text = value; }
        }

        private void Measurement_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(Measurement.Text))
                tbPlaceHolder.Visibility = Visibility.Visible;
            else
                tbPlaceHolder.Visibility = Visibility.Hidden;
        }

        public void ClearInput3()
        {
            Measurement.Clear();

        }
    }
}
