# PROG_2A_POE_PART3 POE
My POE
Part 3

Project Description
For this part we have to make a GUI of the application we made in part 2 while also adding new features to the gui by filter the list of recipes by:
a. entering the name of an ingredient that must be in the recipe,
b. choosing a food group that must be in the recipe, or
c. selecting a maximum number of calories

# How to compile and run the software
Starting off by making the MainWindow in this window you will 4 options in the menu to either add,display search or exit the application.
When you click to add a recipe you will be taken to a new window called AddRecipe where you can enter the name of the recipe and the number of ingredients. After entering the required information, click the "Confirm" button to proceed.
You will contiune the child window and this window is used to add ingredients, food groups, quantities, measurements, and calories for a recipe. Fill in the necessary information and click the "Save recipe" button to save the recipe.
Next it will take you to the AddStepsWindow,this window allows you to specify the number of steps involved in a recipe. Enter the number of steps and click the "Confirm" button. 
You can then go to StepsDescriptionWindow, this window is used to enter descriptions for each step of a recipe. Enter the description and click the "Confirm" button.
After you have done all that you will be taken to the MainWindow again where you can display the entire recipe and then click the back button to go to the Mainwindow again where you search and filter a recipe.
Or you exit out of the program at the end

Some errors may occure when displaying the recipe and flitering the recipe.

# Brief description of what I have changed based on my lecturer’s feedback
Before starting part 3 i had a look  at my lecturers feedback from part 2 and using that to compelete part 3 to the best of my ability.
I updated my readme file well with all the updates in my new readme file. I also explain all my required details in the running of the app
I used execption handling in my gui when the user enters the recipe details so that the program does not crash when entering they do the details.
I made sure to store all the details in the List and made a seprate folder to call that list.
I structed my code well have comments in all my code wear necessary, aswell as have no errors in the code so that it fuctions.

# link to GitHub repository
https://github.com/SethValentine/PROG_2A_POE_PART1
