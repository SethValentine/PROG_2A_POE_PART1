﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace UnitTestProject1
{
    [TestClass]
    public class RecipeCalculatorTests
    {
        [TestMethod]
        public void CalculateTotalCalories_WithEmptyIngredients_ReturnsZero()
        {
            // Arrange
            RecipeCalculator calculator = new RecipeCalculator();
            List<Ingredient> ingredients = new List<Ingredient>();

            // Act
            double totalCalories = calculator.CalculateTotalCalories(ingredients);

            // Assert
            Assert.AreEqual(0, totalCalories);
        }

        [TestMethod]
        public void CalculateTotalCalories_WithIngredients_ReturnsCorrectTotalCalories()
        {
            // Arrange
            RecipeCalculator calculator = new RecipeCalculator();
            List<Ingredient> ingredients = new List<Ingredient>()
            {
                new Ingredient { Name = "Ingredient 1", Quantity = 2, Unit = "grams", Calories = 10 },
                new Ingredient { Name = "Ingredient 2", Quantity = 3, Unit = "grams", Calories = 20 },
                new Ingredient { Name = "Ingredient 3", Quantity = 1, Unit = "grams", Calories = 5 }
            };

            // Act
            double totalCalories = calculator.CalculateTotalCalories(ingredients);

            // Assert
            Assert.AreEqual(2 * 10 + 3 * 20 + 1 * 5, totalCalories);
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    public class RecipeCalculator
    {
        public double CalculateTotalCalories(List<Ingredient> ingredients)
        {
            double totalCalories = 0;
            foreach (var ingredient in ingredients)
            {
                totalCalories += ingredient.Calories;
            }
            return totalCalories;
        }
    }
}
