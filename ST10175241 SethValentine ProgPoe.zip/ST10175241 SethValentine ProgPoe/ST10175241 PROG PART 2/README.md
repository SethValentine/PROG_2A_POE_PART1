# PROG_2A_POE_PART1
My POE
Part 1

Project Description
In the Poe they gave us a background on why we have to make the application we are making they gave an example of how sanele was invited to a birthday party and how there was good food. Sanele wants to learn how to cook so we have delveleoped a recipe book on how to start cooking.
Before we can start building anything we have to writing down what the real problem is and create a pseudo code on how we going to solve this problem and how are going to begin coding.

How to Compile and Run the Software.
We started off with creating the program to state Snaneles Recipe Book
When loading the application you will get  6 instructions you can either add, print, scale, reset, clear or quit
Add: Here you add the number of ingredients you would like to the menu. You ony use integers and you put the amount of how much ingreidents you would like to add whether it be 1,2,3, 4 or any amount of ingreidents you would like. 
After adding the number you will be ask the name the ingreident that you want like milk,eggs, flour ect.
You will then enter the quantiy of the ingrdient you would like then the unit of mearsument for the ingrdients
That will be all depending on how much ingreidents you want

You can then print out the entire ingredients and would give out everything you have typed in
You scale the recipe by a factor of 0.5, 2 or 3
In my Code i only have 2 classes 1 would be the Recipe class and the other is the Ingredient Class
The Recipe class has the following properties in them:
NumOfIngrients: here i have an integer showing the amount of ingreidents in the recipe
Ingredients: this is a list of the inredient object which shows all the ingreidents
NumOfSteps: This is an integer that shows all the steos 
Steps: Gives the list of strings that shows the steps

The next class would be the Ingreident Class which has there properties that is:
Name: this is a string that shows the name of the ingrident
Quantity: a double which shows the quantiy of the ingreident 
Unit: the string which gives the unit of measurnemnt 

There is also a main method which is switch statement that has:
add: the user can add an ingredient
print: prints the recipe you are busy with
scale:scales the recipe you are busy with by 0.5,2 or 3
reset: resets everything to how it is in the beginning
clear:clears the whole program
quit: leaves the program
The reason why i used a switch statement is so that it can handle all the different commands. for example when the user enters an invaid command it will display an error message.


